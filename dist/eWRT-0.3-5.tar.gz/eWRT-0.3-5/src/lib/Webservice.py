#!/usr/bin/env python

class Webservice(object):

    def __init__(self):
        """ implement me """

    def login(self):
        """ implement me """
