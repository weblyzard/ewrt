# library init
