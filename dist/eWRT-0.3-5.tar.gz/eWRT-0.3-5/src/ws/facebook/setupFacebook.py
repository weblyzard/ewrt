

class SetupFacebook(self):

    def __init__(self):
        """ implement me """

    def saveConfigToFile(self):
        """ implement me """
