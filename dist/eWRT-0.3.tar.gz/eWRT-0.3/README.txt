easy Web Retrieval Toolkit (eWRT)
=================================

1. Quickstart:
--------------
adjust
  config.py.sample 
to your setting and save it as config.py

2. Requirements:
---------------

   python-libraries:
   - facebook api - http://code.google.com/p/pyfacebook/
   - google-trends api - http://github.com/suryasev/unofficial-google-trends-api/tree/master
   - oauth - http://oauth.googlecode.com/
   - simplejson - http://pypi.python.org/pypi/simplejson/ 
   - tango - http://tango.ryanmcgrath.org/
